    function Forward = DPOption_Handler(S,r,q,sigma,strike,T,dT,dirac,theta,kappa)
        t = 0;
        while t < T
            t = t + dT;
            dr = (r - q - sigma*sigma/2)*dT;
            pert = sigma*sqrt( dT )*randn();
            S = S*exp(dr + pert);
            sigma = sigma-(dirac*(sigma-theta))*dT + kappa*sqrt(dT)*randn();
            sigma = max(sigma,0);
        end
        Forward = exp(-r*T)*1;
    end
% Adapted from option_pricing at Mathworks