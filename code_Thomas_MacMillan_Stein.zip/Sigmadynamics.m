function [sigmadyn] = Sigmadynamics(T,sigma,dirac,theta,kappa)
Z = randn;
sigmadyn = sigma-dirac*(sigma-theta)*T + kappa*sqrt(T)*Z;
% Discretizado bajo esquema de Euler
end