function [ErrorValues,ErrorV] = getValue(SpotD,StrikeAll,Discount,VolatilitiesD,WorkingDaysD,DomesticDiscountD,ForeignDiscountD,OptionValueD,p,f,s)
V = zeros(2422,35); ErrorV=zeros(2422,35);
for j=f:s
for i=1:2422
   d1=(log(SpotD(i,1)/StrikeAll(i,j))+log(Discount(i,p)))/((VolatilitiesD(i,j)/100)*sqrt(WorkingDaysD(i,p)/365))+(((VolatilitiesD(i,j)/100)*sqrt(WorkingDaysD(i,p)/365))/2);
   d2=d1-((VolatilitiesD(i,j)/100)*sqrt(WorkingDaysD(i,p)/365));
   Z=normcdf(d1);L=normcdf(d2);
   V(i,j)=(SpotD(i,1)*ForeignDiscountD(i,p)*Z)-(StrikeAll(i,j)*DomesticDiscountD(i,p)*L);
   ErrorV(i,j)=abs(V(i,j)-OptionValueD(i,j));
end
end
ErrorValues = mean2(ErrorV);
end

