clear all
% OJO. LAS TASAS DEL EXCEL SON EXP, TENGO QUE DEJARLAS COMO R Y Q
% Datos
Spot = 500;
r = 0.1; %Domestic risk free interest rate
q = 0.05; %Foreign risk free interest rate
sigma = 0.2; %Instantaneous Vol / Constant Vol
% Vanilla Call underlying S
K = 460; %Strike
T = 1; %Maturity
% Par�metros Stein and Stein
dirac = 4;
theta = 0.2;
kappa = 0.1;
% Fin Par�metros
mu = (r-q);
notional = K/Spot;
%Initialize GPU
N = 1000;step=0.1;ArraySpot = Spot*ones(N,1,'gpuArray');[ans]=SteinSteinCall_MCGPU(q,r,T,step,sigma,K,dirac,theta,kappa,ArraySpot,N);
%% Benchmark BS
disp('Benchmark BlackScholes Closed Formula---------------------------------------------------------');
optiontype = 1; %Call
[BlackScholesValue]=getValueBS(K, T, optiontype, r, q, Spot, sigma);
fprintf('Black Scholes Call = %f.\n',BlackScholesValue);
%% Monte-Carlo Stein and Stein
disp('Stein and Stein Monte-Carlo -----------------------------------------------------------------');
t1 = 0;
B = exp(r*T); %Descontador
N = 10000; %Simulaciones
step=0.01;kappa = 0.1; theta = 0.2;dirac=4;K = 460; Spot = 500;
tic;
[MonteCarlo_Call,MonteCarlo_Call_Accuracy] = SteinSteinCall_MC(N,step,t1,r,q,Spot,sigma,K,T,dirac,theta,kappa);
fprintf('Monte Carlo Call = %f.\n',MonteCarlo_Call);
fprintf('Monte Carlo Call Accuracy = %f.\n',MonteCarlo_Call_Accuracy);
toc;
%% Monte-Carlo Stein and Stein GPU
step = 1/12;theta=0.2; kappa=0.1; dirac = 4;K = 460; Spot = 500;
N = 10000; % Muy Bueno con 1.000.000
ArraySpot = Spot*ones(N,1,'gpuArray');
tic
[GPU_Call,GPU_Accuracy] = SteinSteinCall_MCGPU(q,r,T,step,sigma,K,dirac,theta,kappa,ArraySpot,N);
toc
fprintf( 'GPU Monte Carlo Call %1.4f.\n', GPU_Call);
fprintf( 'GPU Monte Carlo Accuracy %1.4f.\n', GPU_Accuracy);
%% Closed Form
disp('Stein and Stein Closed Form -----------------------------------------------------------------');
dirac = 4;
theta = 0.2;
kappa = 0.1;
mu = (r-q); K = 460; Spot = 500;
notional = K/Spot;
tic
[Closed_Call] = SolveSegundaIntegral(dirac,kappa,theta,sigma,mu,T,notional,r,Spot);
fprintf('Closed Form Call = %f.\n',Closed_Call);
toc
%% Plot Prices VS Spots
K = 100;optiontype=1;
vectorspots = 50:10:200;
savevalues = zeros(3,length(vectorspots));
j=1;
dirac = 0.001; %Black Scholes Params for Stein and Stein, Son peque�os pq en 0 se indefine la integral. 
kappa = 0.001;
for i=vectorspots
    notional = K/i;
    [BlackScholesValue]=getValueBS(K, T, optiontype, r, q, i, sigma);
    ArraySpot = i*ones(N,1,'gpuArray');
    [GPU_Call] = SteinSteinCall_MCGPU(q,r,T,step,sigma,K,dirac,theta,kappa,ArraySpot,N);
    [Closed_Call] = SolveSegundaIntegral(dirac,kappa,theta,sigma,mu,T,notional,r,i);
    savevalues(1,j) = BlackScholesValue;
    savevalues(2,j) = gather(GPU_Call);
    savevalues(3,j) = Closed_Call;
    j = j+1;
end
figure(1);
plot(vectorspots,savevalues(1,:),'k');
hold on
plot(vectorspots,savevalues(2,:));
hold on
plot(vectorspots,savevalues(3,:));
legend('Black-Scholes','MonteCarlo GPU','Closed Formula');
hold off
%% Verificaci�n Forward
T=0.5;K=120;Spot=100;sigma=0.2;r=log(1.1);q=0;
%BS
optiontype = 1; %Call
[BSCALL]=getValueBS(K, T, optiontype, r, q, Spot, sigma);
optiontype = -1;
[BSPUT]=getValueBS(K, T, optiontype, r, q, Spot, sigma); F = BSCALL - BSPUT;
fprintf('Forward= %f.\n',F);
%Fin BS
%MonteCarlo
dirac = 0;kappa=0; theta = 0.2;
step = 0.01;N = 100000; % Muy Bueno con 1.000.000
ArraySpot = Spot*ones(N,1,'gpuArray');
[GPU_Forward, GPU_FA] = SteinSteinForward_MCGPU(q,r,T,step,sigma,K,dirac,theta,kappa,ArraySpot,N);
fprintf( 'GPU Monte Carlo Forward %1.4f. +- %1.4f\n', GPU_Forward, GPU_FA);
%Fin MonteCarlo
%% Verificaci�n Deposito a Plazo
Spot=1;r=0.2;q=0;T=2;
%{
optiontype = 1; %Call
[SpotFuturo]=getValueBS(0, T, optiontype, r, q, Spot, sigma);
optiontype = -1; %Put
[SpotFuturo2]=getValueBS(0, T, optiontype, r, q, Spot, sigma);
DP = (SpotFuturo-SpotFuturo2);  % DP = exp(-r*T) pero es como si calculara una Call con Strike 0, y sin el exp pq BS ya lo trae a Valor Presente
%}
DP = exp(-r*T);
fprintf('DP = %f.\n',DP);
%MonteCarlo
dirac = 0;kappa=0; theta = 0.2;
step = 0.01;N = 10000; % Muy Bueno con 1.000.000
ArraySpot = Spot*ones(N,1,'gpuArray');
[GPU_DP] = SteinSteinDP_MCGPU(q,r,T,step,sigma,K,dirac,theta,kappa,ArraySpot,N);
fprintf( 'GPU Monte Carlo DP %1f.\n', GPU_DP);
%Fin MonteCarlo
%% Newton Rapson
K = 460; T=1; Spot = 500; volAccuracy = 0.0001; 
dirac = 4; theta = 0.2; kappa = 0.1;
initialguess = 0.1;
%Params GPU MC
N = 10000; step = 0.01;
ArraySpot = Spot*ones(N,1,'gpuArray');
tic
[CallStein] = SteinSteinCall_MCGPU(q,r,T,step,sigma,K,dirac,theta,kappa,ArraySpot,N);
[ImpVol] = NewtonRapsonGood(CallStein,K,T,1,r,q,Spot,volAccuracy,initialguess);
fprintf('Implied Vol= %f.\n',ImpVol);
toc
%% ImpVol Versus Dirac/Theta/Kappa
N = 10000;
Spot = 500; K=460;ArraySpot = Spot*ones(N,1,'gpuArray');volAccuracy = 0.00001;step=0.01;
q=0.05;r=0.1;T=1;
initialguess = 0.1;

vectordirac = 1:0.1:25;
vectortheta = 0.01:0.01:1;
vectorkappa = 0.01:0.01:1;
savevolatility1 = zeros(2,length(vectordirac));
savevolatility2 = zeros(1,length(vectortheta));
savevolatility3 = zeros(1,length(vectorkappa));
j=1;
% Par�metros Stein and Stein
dirac = 4;
theta = 0.2;
kappa = 0.1;
% Fin Par�metros
tic
%Delta
for i=vectordirac    
    [CallStein] = SteinSteinCall_MCGPU(q,r,T,step,sigma,K,i,theta,kappa,ArraySpot,N);
    [ImpVol] = NewtonRapsonGood(gather(CallStein),K,T,1,r,q,Spot,volAccuracy,initialguess);
    savevolatility1(1,j) = ImpVol;
    savevolatility1(2,j) = gather(CallStein);
    j = j+1;
end
figure(2);
plot(vectordirac,savevolatility1(1,:),'r');
xlabel('delta')
ylabel('Implied Volatility')
title('Implied Volatility vs Delta')
toc
%Theta
tic
j=1;
for i=vectortheta    
    [CallStein] = SteinSteinCall_MCGPU(q,r,T,step,sigma,K,dirac,i,kappa,ArraySpot,N);
    [ImpVol2] = NewtonRapsonGood(gather(CallStein),K,T,1,r,q,Spot,volAccuracy,initialguess);
    savevolatility2(1,j) = ImpVol2;
    j = j+1;
end
figure(3);
plot(vectortheta,savevolatility2(1,:),'b');
xlabel('Theta')
ylabel('Implied Volatility')
title('Implied Volatility vs Theta')
toc
%Kappa
tic
j=1;
for i=vectorkappa  
    [CallStein] = SteinSteinCall_MCGPU(q,r,T,step,sigma,K,dirac,theta,i,ArraySpot,N);
    [ImpVol3] = NewtonRapsonGood(gather(CallStein),K,T,1,r,q,Spot,volAccuracy,initialguess);
    savevolatility3(1,j) = ImpVol3;
    j = j+1;
end
figure(4);
plot(vectortheta,savevolatility3(1,:),'c');
xlabel('Kappa')
ylabel('Implied Volatility')
title('Implied Volatility vs Kappa')
toc
%% Valor Call vs Dirac/Theta/Kappa
N = 10000;
Spot = 500; K=460;notional = K/Spot;ArraySpot = Spot*ones(N,1,'gpuArray');step=0.01;
vectordirac = 1:0.1:25;
vectortheta = 0.01:0.01:1;
vectorkappa = 0.01:0.01:1;
saveprice1 = zeros(2,length(vectordirac));
saveprice2 = zeros(2,length(vectortheta));
saveprice3 = zeros(2,length(vectorkappa));
% Par�metros Stein and Stein
dirac = 4;
theta = 0.2;
kappa = 0.1;
% Fin Par�metros
%Delta--------------------------------------------ONE-----------------------------------------------------------------
j=1;
for i=vectordirac    
    [Price1] = SteinSteinCall_MCGPU(q,r,T,step,sigma,K,i,theta,kappa,ArraySpot,N);
    [Closed_Call] = SolveSegundaIntegral(i,kappa,theta,sigma,mu,T,notional,r,Spot);
    saveprice1(1,j) = gather(Price1);
    saveprice1(2,j) = Closed_Call;
    j = j+1;
end
figure(5);
plot(vectordirac,saveprice1(1,:),'r');
hold on
plot(vectordirac,saveprice1(2,:),'c');
xlabel('delta')
ylabel('Call Value')
title('Call vs Delta')
toc
%Theta--------------------------------------------TWO-----------------------------------------------------------------
tic
j=1;
for i=vectortheta    
    [Price2] = SteinSteinCall_MCGPU(q,r,T,step,sigma,K,dirac,i,kappa,ArraySpot,N);
    [Closed_Call2] = SolveSegundaIntegral(dirac,kappa,i,sigma,mu,T,notional,r,Spot);
    saveprice2(1,j) = gather(Price2);
    saveprice2(2,j) = Closed_Call2;
    j = j+1;
end
figure(6);
plot(vectortheta,saveprice2(1,:),'b');
hold on
plot(vectortheta,saveprice2(2,:),'k');
xlabel('Theta')
ylabel('Call Value')
title('Call vs Theta')
toc
%Kappa----------------------------------------------THREE---------------------------------------------------------------
tic
j=1;
for i=vectorkappa  
    [Price3] = SteinSteinCall_MCGPU(q,r,T,step,sigma,K,dirac,theta,i,ArraySpot,N);
    [Closed_Call3] = SolveSegundaIntegral(dirac,i,theta,sigma,mu,T,notional,r,Spot);
    saveprice3(1,j) = gather(Price3);
    saveprice3(2,j) = Closed_Call3;
    j = j+1;
end
figure(7);
plot(vectorkappa,saveprice3(1,:),'c');
hold on
plot(vectorkappa,saveprice3(2,:),'k');
xlabel('Kappa')
ylabel('Call Value')
title('Call vs Kappa')
toc
%-------------------------------------------------------------------------------------------------------------------