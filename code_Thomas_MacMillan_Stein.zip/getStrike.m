function [ErrorStrikes,alpha] = getStrike(DomesticDiscountD, ForeignDiscountD,SpotD,Discount,VolatilitiesD,WorkingDaysD,StrikeD,DO,F,DI,alpha,p,f,s)

delta = [0.1 0.25 0.35 0.5 0.65 0.75 0.9]; %Pilares
K = zeros(2422,35);ErrorK = zeros(2422,35);
for j=f:s
for i=1:2422
    %alpha = exp(-log(DomesticDiscountD(i,DO))); % 3.966e-04
    alpha = 1; % 3.433 e-04
    %alpha = ForeignDiscountD(i,p);
    d1 = norminv( (delta(1,j-(7*(p-1)))/alpha) ); % a) (delta(1,j)/exp(-ForeignDiscountD(i,F))) b) (delta(1,j)/exp(DomesticDiscountD(i,1))) c) delta(1,j))
    K(i,j) = SpotD(i,1)*Discount(i,p)*exp(((((VolatilitiesD(i,j)/100)^2)*(WorkingDaysD(i,p)/365))/2)-d1*(VolatilitiesD(i,j)/100)*sqrt(WorkingDaysD(i,p)/365));
    ErrorK(i,j) = abs(K(i,j)-StrikeD(i,j));
end
end
ErrorStrikes = mean2(ErrorK);

end