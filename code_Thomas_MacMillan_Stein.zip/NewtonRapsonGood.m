function [impVol] = NewtonRapsonGood(Vmkt,strike,terminYears,optiontype,rateCLP,rateUSD,spot,volAccuracy,initialguess)
impVol = initialguess;
error = volAccuracy+1;
while  error > volAccuracy
    Z = impVol;
    [value,vega]=getValueBS(strike,terminYears,optiontype,rateCLP,rateUSD,spot,Z);
    impVol = Z + (Vmkt-value)/vega;
    error=abs(impVol-Z);
end
end