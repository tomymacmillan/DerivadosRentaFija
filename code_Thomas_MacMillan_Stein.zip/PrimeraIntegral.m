function [fun] = PrimeraIntegral(dirac,kappa,theta,sigma,mu,T,precio,eta)
A = -dirac./(kappa.^2);
B = (theta.*dirac)./(kappa.^2);
lamda = (eta.^2 + 0.25).*(T./2);
C = -(lamda)./((kappa.^2).*T);
a = (A.^2 - 2.*C).^(0.5);
b = -A./a;
aux1 = sinh(a.*(kappa.^2).*T);
aux2 = cosh(a.*(kappa.^2).*T);
L = -A -a.*((aux1+(b.*(aux2)))./(aux2+(b.*(aux1))));
M = B.*(((b.*aux1 + (b.^2).*(aux2) + 1 - b.^2)./(aux2 + b.*aux1))-1);
aux4 = (A + a + (a - A).*(exp(2.*a.*(kappa.^2).*T)));
aux3 = ((2.*A + a) + (2.*A - a).*(exp(2.*a.*(kappa.^2).*T)))./(aux4);
aux5 = ((2.*A.*(B.^2)).*(a.^2 - A.^2).*(exp(a.*(kappa.^2).*T)))./((a.^3).*(A + a + (a - A).*(exp(2.*a.*(kappa.^2).*T))));
aux6 = 0.5.*(log(((0.5.*((A./a) +1)) + (0.5.*(1-(A./a)).*exp(2.*a.*(kappa.^2).*T)))));
N = ((a-A)./(2.*a.^2)).*((a.^2 - A.*(B.^2) - (B.^2).*a).*((kappa.^2).*T)) + ((((B.^2).*(A.^2 - a.^2))./(2.*(a.^3))).*aux3) + aux5 - aux6;
I = exp((L.*(sigma.^2))./2 + M.*sigma + N);
fun = I.*exp(1i.*eta.*log(precio.*exp(-mu.*T)));
end

