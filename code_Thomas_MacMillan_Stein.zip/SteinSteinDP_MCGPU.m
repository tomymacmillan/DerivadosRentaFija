function [meanOptionPrice,accuracy] = SteinSteinDP_MCGPU(q,r,T,dT,sigma,K,dirac,theta,kappa,ArraySpot,N)
optionPrices = arrayfun( @DPOption_Handler, ArraySpot, r, q, sigma, K, T, dT, dirac, theta, kappa);
meanOptionPrice = mean(optionPrices);
accuracy = std(optionPrices)/sqrt(N);
end

