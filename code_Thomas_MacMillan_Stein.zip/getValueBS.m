function [value,vega] = getValueBS(strike,T,optiontype,r,q,spot,sigma)
d1=(log(spot/strike)+(r-q)*T)/(sigma*sqrt(T))+((sigma*sqrt(T))/2);
d2=d1-sigma*sqrt(T);
value = optiontype*spot*exp(-q*T)*normcdf(optiontype*d1)-optiontype*strike*exp(-r*T)*normcdf(optiontype*d2);
vega = spot*exp(-q*T)*normpdf(d1)*sqrt(T);
%delta = optiontype*exp(-q*T)*normcdf(optiontype*d1);
%gamma = exp(-q*T)*(normpdf(d1)/(spot*sigma*sqrt(T)));
%theta = -((spot*normpdf(d1)*sigma)/(2*sqrt(T)))-optiontype*r*strike*exp(-r*T)*normcdf(optiontype*d2)+optiontype*q*spot*exp(-q*T)*normcdf(optiontype*d1);
end
