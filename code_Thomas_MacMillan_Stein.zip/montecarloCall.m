function [MC_estimado0,MC_accuracy] = montecarloCall(N,T,t1,r,q,Spot,sigma,K,B,optiontype)
i=0;o=0;p=0; %Acumuladores
for j=1:N
    %Valor S en T
    [bsanalytical]=Sdynamics(T,t1,r,q,Spot,sigma);
    %Payoff Call
    payoff=max(optiontype*(bsanalytical-K),0);
    %Descontar Payoff
    [descontado] = getdiscountY(payoff,B);
    %Acumuladores
    i=i+1;o=o+descontado;p=p+descontado^2;
end
MC_estimado0 = o/i;
MC_accuracy = (1/sqrt(i))*sqrt((p/i)-(MC_estimado0^2));
end

