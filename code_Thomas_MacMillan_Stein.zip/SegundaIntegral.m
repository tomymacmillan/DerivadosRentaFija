function [fun] = SegundaIntegral(dirac,kappa,theta,sigma,mu,T,K,P)
fun = (P-K)*SolvePrimeraIntegral(dirac,kappa,theta,sigma,mu,T,P);
end

