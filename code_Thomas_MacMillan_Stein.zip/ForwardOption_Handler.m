    function Forward = ForwardOption_Handler(S,r,q,sigma,strike,T,dT,dirac,theta,kappa)
        t = 0;
        while t < T
            sigma = sigma-(dirac*(sigma-theta))*dT + kappa*sqrt(dT)*randn();
            sigma = max(sigma,0);
            t = t + dT;
            dr = (r - q - sigma*sigma/2)*dT;
            pert = sigma*sqrt( dT )*randn();
            S = S*exp(dr + pert);
        end
        Forward = exp(-r*T)*(S - strike);
    end
% Adapted from option_pricing at Mathworks