function [MC_estimado,MC_accuracy] = SteinSteinCall_MC(N,step,t1,r,q,Spot,sigma,K,T,dirac,theta,kappa)
i=0;o=0;p=0;%Acumuladores
Tend = int8((step^(-1))*T);
for j=1:N
    spotnew = Spot; sigmanew = sigma; spotdyn=0;sigmadyn=sigma;
    for u=1:Tend
    [spotdyn]=Sdynamics(step,t1,r,q,spotnew,sigmadyn);
    [sigmadyn] = Sigmadynamics(step,sigmanew,dirac,theta,kappa);
    %sigmadyn = max(sigmadyn,0);
    spotnew = spotdyn; sigmanew = sigmadyn;
    end
    %Descontar Payoff
    payoff = max((spotdyn-K),0);
    descontado = payoff/(exp(r*T));
    %Acumuladores
    i=i+1;o=o+descontado;p=p+descontado^2;
end
MC_estimado = o/i;
MC_accuracy = (1/sqrt(i))*sqrt((p/i)-(MC_estimado^2));
end

