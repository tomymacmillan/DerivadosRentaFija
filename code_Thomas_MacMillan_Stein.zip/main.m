% D.A Project 2017
% Modelo de Volatilidad Estoc�stica Stein and Stein
% Thomas Mac Millan
clear all
% Importar Datos
filename = 'data.csv';filename2 = 'dates.xlsx';
SpotD = csvread(filename,0,0,[0 0 2421 0]);
VolatilitiesD = csvread(filename,0,1,[0 1 2421 35]);
VolatilitiesD1 = csvread(filename,0,1,[0 1 2421 7]);
VolatilitiesD2 = csvread(filename,0,8,[0 8 2421 14]);
VolatilitiesD3 = csvread(filename,0,15,[0 15 2421 21]);
VolatilitiesD6 = csvread(filename,0,22,[0 22 2421 28]);
VolatilitiesD12 = csvread(filename,0,29,[0 29 2421 35]);
WorkingDaysD = csvread(filename,0,36,[0 36 2421 40]);
DomesticDiscountD = csvread(filename,0,41,[0 41 2421 45]);
ForeignDiscountD = csvread(filename,0,46,[0 46 2421 50]);
ForwardPointsD = csvread(filename,0,51,[0 51 2421 55]);
StrikeD = csvread(filename,0,56,[0 56 2421 62]);
StrikeD2 = csvread(filename,0,63,[0 63 2421 69]);
StrikeD3 = csvread(filename,0,70,[0 70 2421 76]);
StrikeD6 = csvread(filename,0,77,[0 77 2421 83]);
StrikeD12 = csvread(filename,0,84,[0 84 2421 90]);
StrikeAll = csvread(filename,0,56,[0 56 2421 90]);
OptionValueD = csvread(filename,0,91,[0 91 2421 125]);
[~, datesarray] = xlsread(filename2,'Sheet1');
DateD = string(datesarray);
t = datetime(datesarray,'InputFormat','dd/MM/yy');
DateD2 = {'2008' '2009' '2010' '2011' '2012' '2013' '2014' '2015' '2016' '2017'};
%% Step 2
%Volatilidad Vs Tiempo
figure(1);
DateD2 = {'2008' '2009' '2010' '2011' '2012' '2013' '2014' '2015' '2016' '2017'};
plot(VolatilitiesD(:,4),'b');hold on % 1 Mes
plot(VolatilitiesD(:,18),'r');hold on % 3 Meses
plot(VolatilitiesD(:,25),'k');hold on % 6 Meses
plot(VolatilitiesD(:,32),'g'); % 12 Meses
set(gca,'XTick',[1 263 523 784 1044 1306 1567 1828 2086 2346],'XTickLabel',DateD2);
xlabel('Tiempo');ylabel('Volatilidad ATM');
legend('1 Mes','3 Meses','6 Meses','1 A�o','Location','northeast');hold off
%Spot Vs Tiempo
figure(2);
plot(SpotD);
set(gca,'XTick',[1 263 523 784 1044 1306 1567 1828 2086 2346],'XTickLabel',DateD2);
xlabel('Tiempo');ylabel('Spot');
%Volatilidad vs Spot
figure(3)
scatter(SpotD,VolatilitiesD(:,4)); hold on
scatter(SpotD,VolatilitiesD(:,18)); hold on
scatter(SpotD,VolatilitiesD(:,25)); hold on
scatter(SpotD,VolatilitiesD(:,32)); hold on
xlabel('Spot');ylabel('Volatilidad ATM');
legend('1 Mes','3 Meses','6 Meses','1 A�o','Location','northeast');hold off
%% Step 3
% Precios Forward
[~,Discount] = getForward(DomesticDiscountD,ForeignDiscountD,SpotD,ForwardPointsD);

%Strike

alpha = 0;

DO=1;F=1;DI=1;
[ErrorStrikes] = getStrike(DomesticDiscountD, ForeignDiscountD,SpotD,Discount,VolatilitiesD,WorkingDaysD,StrikeAll,DO,F,DI,alpha,1,1,7);
DO=2;F=2;DI=2;
[ErrorStrikes2] = getStrike(DomesticDiscountD, ForeignDiscountD,SpotD,Discount,VolatilitiesD,WorkingDaysD,StrikeAll,DO,F,DI,alpha,2,8,14);
DO=3;F=3;DI=3;
[ErrorStrikes3] = getStrike(DomesticDiscountD, ForeignDiscountD,SpotD,Discount,VolatilitiesD,WorkingDaysD,StrikeAll,DO,F,DI,alpha,3,15,21);
DO=4;F=4;DI=4;
[ErrorStrikes4] = getStrike(DomesticDiscountD, ForeignDiscountD,SpotD,Discount,VolatilitiesD,WorkingDaysD,StrikeAll,DO,F,DI,alpha,4,22,28);
DO=5;F=5;DI=5;
[ErrorStrikes5] = getStrike(DomesticDiscountD, ForeignDiscountD,SpotD,Discount,VolatilitiesD,WorkingDaysD,StrikeAll,DO,F,DI,alpha,5,29,35);
TotalErrorStrikes = (ErrorStrikes+ErrorStrikes2+ErrorStrikes3+ErrorStrikes4+ErrorStrikes5)/5


% Valor Prima
[ErrorValue1] = getValue(SpotD,StrikeAll,Discount,VolatilitiesD,WorkingDaysD,DomesticDiscountD,ForeignDiscountD,OptionValueD,1,1,7);
[ErrorValue2] = getValue(SpotD,StrikeAll,Discount,VolatilitiesD,WorkingDaysD,DomesticDiscountD,ForeignDiscountD,OptionValueD,2,8,14);
[ErrorValue3] = getValue(SpotD,StrikeAll,Discount,VolatilitiesD,WorkingDaysD,DomesticDiscountD,ForeignDiscountD,OptionValueD,3,15,21);
[ErrorValue4] = getValue(SpotD,StrikeAll,Discount,VolatilitiesD,WorkingDaysD,DomesticDiscountD,ForeignDiscountD,OptionValueD,4,22,28);
[ErrorValue5] = getValue(SpotD,StrikeAll,Discount,VolatilitiesD,WorkingDaysD,DomesticDiscountD,ForeignDiscountD,OptionValueD,5,29,35);
TotalErrorValue = (ErrorValue1+ErrorValue2+ErrorValue3+ErrorValue4+ErrorValue5)/5

%% Instant Vol
InstVol = zeros(2422,1);
for m=1:2421
InstVol(m,1) = (abs(log(SpotD(m+1,1))-log(SpotD(m,1))))^(1/2);
end
InstVol(2422,1) = InstVol(2420,1);
%% Calibraci�n
T = (WorkingDaysD./365);
r = -log(DomesticDiscountD)./T;
q = -log(ForeignDiscountD)./T;

sigma = 0.1;
dirac = 50;
theta = 0.0922;
kappa = 0.4;
DIASTART = 1;
DIASEND = 2422; 
MatrixStein = zeros(length(DIASEND),35);
maxevaluations = 10;
%____________________________________________________________________________________________________________________
MatrixParams = zeros(3,length(DIASEND));
MatrixErrores = zeros(1,length(DIASEND));
%{
sigma = 0.1;
dirac = 62;
theta = 0.0428;
kappa = 0.3805;
DIASEND = 2422; 
DIASTART = 1685;
%}
%____________________________________________________________________________________________________________________
Spot = SpotD; %Vector All Spots
K = StrikeAll; %Vector Strikes
step = T./100; %Vector
N = 10000;

x0 = [dirac theta kappa];
options = optimset('MaxIter',maxevaluations,'MaxFunEvals',maxevaluations);

timeLimit = 15;
p=DIASTART;

for p=DIASTART:DIASEND 
tic
[x, val] = fminsearch(@(x0)DosFor2(Spot,q,r,T,step,K,N,VolatilitiesD,InstVol(p,1),x0,p,MatrixStein),x0,options);
[~,MatrixStein]= DosFor2(Spot,q,r,T,step,K,N,VolatilitiesD,InstVol(p,1),x0,1,MatrixStein);
fprintf( 'Valores %1.4f.\n', x);
if x(1,1) < 50
    x(1,1) = 50;
elseif x(1,1) > 60
    x(1,1) = 60;
elseif x(1,2) > 0.1
    x(1,2) = 0.1;
elseif x(1,3) > 0.8
    x(1,3) = 0.8;
elseif x(1,2) < 0.05
    x(1,2) = 0.05;
elseif x(1,3) < 0.4
    x(1,3) = 0.4;
end
MatrixParams(1,p) = x(1,1);
MatrixParams(2,p) = x(1,2);
MatrixParams(3,p) = x(1,3);
x0 = x;
fprintf( 'Dia %1.0f.\n', p);
if toc > timeLimit
    x(1,1) = MatrixParams(1,p);
    x(1,2) = MatrixParams(2,p);
    x(1,3) = MatrixParams(3,p);
    fprintf( 'Abortando');
    continue
end
MatrixErrores(1,p) = val;
end


%Plotear Errores
figure(10)
plot(MatrixErrores);
set(gca,'XTick',[1 263 523 784 1044 1306 1567 1828 2086 2346],'XTickLabel',DateD2);
xlabel('D�as');ylabel('Error % de Volatilidad');

%Calcula Error Medio
meanerror = mean(MatrixErrores);sderror = std(MatrixErrores);
fprintf( 'Mean Error %1.4f.\n', meanerror);
fprintf( 'Sd Error %1.4f.\n', sderror);

%Smile del Dia que quiero

g = 1; %DIA
figure(1)
plot(VolatilitiesD(g,1:7),'-r');
hold on
plot(VolatilitiesD(g,8:14),'-g');
plot(VolatilitiesD(g,15:21),'-m');
plot(VolatilitiesD(g,22:28),'-k');
plot(VolatilitiesD(g,29:35),'-c');
plot(MatrixStein(g,1:7),'-.r');
plot(MatrixStein(g,8:14),'-.g');
plot(MatrixStein(g,15:21),'-.m');
plot(MatrixStein(g,22:28),'-.k');
plot(MatrixStein(g,29:35),'-.c');
set(gca,'XTick',1:7,'XTickLabel',['10P';'25P';'35P';'ATM';'35C';'25C';'10C']);
axis([1 7 8 13]);
%legend('DATA','Stein');
hold off


%% Plot Params
DateD2 = {'2008' '2009' '2010' '2011' '2012' '2013' '2014' '2015' '2016' '2017'};

figure(1)
subplot(3,1,1)
plot(MatrixParams(1,:),'b'); %Dirac
xlabel('D�as');ylabel('Delta');
axis([0 DIASEND 0 65]);
set(gca,'XTick',[1 263 523 784 1044 1306 1567 1828 2086 2346],'XTickLabel',DateD2);
%figure(2)
subplot(3,1,2)
plot(MatrixParams(2,:),'r'); %Theta
xlabel('D�as');ylabel('Theta');
axis([0 DIASEND 0 1]);
set(gca,'XTick',[1 263 523 784 1044 1306 1567 1828 2086 2346],'XTickLabel',DateD2);
%figure(3)
subplot(3,1,3)
plot(MatrixParams(3,:),'y'); %Kappa
xlabel('D�as');ylabel('Kappa');
axis([0 DIASEND 0 1]);
set(gca,'XTick',[1 263 523 784 1044 1306 1567 1828 2086 2346],'XTickLabel',DateD2);
%% Std params
meandelta = mean(MatrixParams(1,:));meantheta = mean(MatrixParams(2,:));meankappa = mean(MatrixParams(3,:));
sddelta = std(MatrixParams(1,:));sdtheta = std(MatrixParams(2,:));sdkappa = std(MatrixParams(3,:));
fprintf( 'Mean Delta %1.4f.\n', meandelta);
fprintf( 'Mean Theta %1.4f.\n', meantheta);
fprintf( 'Mean Kappa %1.4f.\n', meankappa);
fprintf( 'Sd Delta %1.4f.\n', sddelta);
fprintf( 'Sd Theta %1.4f.\n', sdtheta);
fprintf( 'Sd Kappa %1.4f.\n', sdkappa);

meanerror = mean(MatrixErrores);sderror = std(MatrixErrores);
fprintf( 'Mean Error %1.4f.\n', meanerror);
fprintf( 'Sd Error %1.4f.\n', sderror);

%% Calcular Errores
%MatrixErrores = zeros(1,2422);
params = MatrixParams';
k=1;
for k=263:2422
    [sumaerrores] = DosFor2(Spot,q,r,T,step,K,N,VolatilitiesD,InstVol(k,1),params(k,:),k);
    MatrixErrores(1,k) = sumaerrores;
    k
end
plot(MatrixErrores);
set(gca,'XTick',[1 263 523 784 1044 1306 1567 1828 2086 2346],'XTickLabel',DateD2);
xlabel('D�as');ylabel('Error % de Volatilidad');
%% plot error
plot(MatrixErrores);
set(gca,'XTick',[1 263 523 784 1044 1306 1567 1828 2086 2346],'XTickLabel',DateD2);
xlabel('D�as');ylabel('Error % de Volatilidad');