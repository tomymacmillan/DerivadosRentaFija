function [sumaerrores,MatrixStein] = DosFor2(Spot,q,r,T,step,K,N,VolatilitiesD,sigma,x0,p,MatrixStein)
sumaerrores = 0;
dirac = x0(1,1);
theta = x0(1,2);
kappa = x0(1,3);


for j=1:5 %Para los 5 Tenors
for i=1:7 %Para los 7 Delta
ArraySpot = Spot(p,1)*ones(N,1,'gpuArray'); %un d�a
[GPU_Call] = SteinSteinCall_MCGPU(q(p,j),r(p,j),T(p,j),step(p,j),sigma,K(p,i+(7*(j-1))),dirac,theta,kappa,ArraySpot,N);
[ImpVol] = NewtonRapsonGood(gather(GPU_Call),K(p,i+(7*(j-1))),T(p,j),1,r(p,j),q(p,j),Spot(p,1),0.001,0.15);
if isnan(ImpVol)
   ImpVol = VolatilitiesD(p,i+(7*(j-1)));
end
MatrixStein(p,i+(7*(j-1))) = ImpVol*100;
sumaerrores = abs(VolatilitiesD(p,i+(7*(j-1)))-MatrixStein(p,i+(7*(j-1)))) + sumaerrores;
end
end
sumaerrores = sumaerrores/(i*j);
end

