clear all
% OJO. LAS TASAS DEL EXCEL SON EXP, TENGO QUE DEJARLAS COMO R Y Q
% Datos
Spot = 1.9808;
r = 0.0423; %Domestic risk free interest rate
q = -0.0513; %Foreign risk free interest rate
% Vanilla Call underlying S
K = 1.9222264; %Strike
T = 33/365; %Maturity
% Par�metros Stein and Stein
sigma = 0.06; %Instantaneous Vol / Constant Vol
theta = 0.09;
dirac = 4;
kappa = 0.2;
% Fin Par�metros
mu = (r-q);
notional = K/Spot;
%Initialize GPU
N = 10000;step=T/12;ArraySpot = Spot*ones(N,1,'gpuArray');[ans]=SteinSteinCall_MCGPU(q,r,T,step,sigma,K,dirac,theta,kappa,ArraySpot,N);
%% Monte-Carlo Stein and Stein GPU
ArraySpot = Spot*ones(N,1,'gpuArray');
tic
[GPU_Call,GPU_Accuracy] = SteinSteinCall_MCGPU(q,r,T,step,sigma,K,dirac,theta,kappa,ArraySpot,N);
toc
fprintf( 'GPU Monte Carlo Call %1.4f +- %1.4f.\n', GPU_Call, GPU_Accuracy);
%% Closed
%[Closed_Call] = SolveSegundaIntegral(dirac,kappa,theta,sigma,mu,T,notional,r,Spot);
%fprintf('Closed Form Call = %f.\n',Closed_Call);
%% BS
optiontype = 1; %Call
[BlackScholesValue]=getValueBS(K, T, optiontype, r, q, Spot, sigma);
fprintf('Black Scholes Call = %f.\n',BlackScholesValue);
%% Print
%{
if GPU_Call+GPU_Accuracy < Closed_Call || GPU_Call-GPU_Accuracy < Closed_Call
    fprintf('Black Scholes Call = %f.\n',BlackScholesValue);
    fprintf('Closed Form Call = %f.\n',Closed_Call);
    fprintf( 'GPU Monte Carlo Call %1.4f +- %1.4f.\n', GPU_Call, GPU_Accuracy);
else
    fprintf('error');
end
%}
%{
savebench = zeros(3,5);j=1;
for i=80:10:120
    notional = K/i;
    ArraySpot = i*ones(N,1,'gpuArray');
    [GPU_Call,GPU_Accuracy] = SteinSteinCall_MCGPU(q,r,T,step,sigma,K,dirac,theta,kappa,ArraySpot,N);
    [Closed_Call] = SolveSegundaIntegral(dirac,kappa,theta,sigma,mu,T,notional,r,i);
    savebench(1,j) = gather(GPU_Call)+gather(GPU_Accuracy);
    savebench(2,j) = gather(GPU_Call)-gather(GPU_Accuracy);
    savebench(3,j) = Closed_Call; 
    j = j+1;
end
plot(80:10:120,savebench(1,:),'k');
hold on
plot(80:10:120,savebench(2,:),'k');
hold on
plot(80:10:120,savebench(3,:),'c');
hold on
legend('Intervalo MC Superior','Intervalo MC Inferior','Formula Cerrada');
hold off
xlabel('Strike');ylabel('Valor Call');
%}
%{
prob = 0;tamano=0;j=0;
oso = 100;
for i=1:oso
    [GPU_Call,GPU_Accuracy] = SteinSteinCall_MCGPU(q,r,T,step,sigma,K,dirac,theta,kappa,ArraySpot,N);
    if GPU_Call+GPU_Accuracy < Closed_Call || GPU_Call-GPU_Accuracy< Closed_Call
        prob = prob + 1;
    else
        tamano = tamano + abs(GPU_Call-GPU_Accuracy - Closed_Call);
        j = j +1;
    end
end
prob = prob/oso;
tamano = tamano/j;
display(prob);
display(tamano);
%}