function [ErrorForwards,Discounts] = getForward(DomesticDiscountD,ForeignDiscountD,SpotD,ForwardPointsD)
F = zeros(2422,5); Error = zeros(2422,5); Discount=zeros(2422,5);
for j=1:5
for i=1:2422
    Discount(i,j) = ForeignDiscountD(i,j)/DomesticDiscountD(i,j);
    F(i,j) = SpotD(i,1)*Discount(i,j);
    Error(i,j) = abs(F(i,j)-(SpotD(i,1)+(ForwardPointsD(i,j)/1000)));
end
end
ErrorForwards = mean2(Error)
Discounts=Discount;
end

