function [bsanalytical] = Sdynamics(T,t1,r,q,spot,sigma)
Z = randn;
bsanalytical = spot*exp((r-q-((sigma^2)/2))*(T-t1)+sigma*sqrt(T-t1)*Z);
% Discretizado bajo esquema de Euler
end