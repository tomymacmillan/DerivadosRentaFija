    function Call = CallOption_Handler(S,r,q,sigma,strike,T,dT,dirac,theta,kappa)
        t = 0;
        while t < T
            t = t + dT;
            dr = (r - q - (sigma^2)/2)*dT;
            pert = sigma*sqrt( dT )*randn();
            S = S*exp(dr + pert);
            sigma = sigma-dirac*(sigma-theta)*dT + kappa*sqrt(dT)*randn();
            sigma = max(sigma,0);
        end
       Call = exp(-r*T)*max(0, S - strike);
    end
% Adapted from option_pricing at Mathworks