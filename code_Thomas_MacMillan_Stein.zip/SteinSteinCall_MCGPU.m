function [meanOptionPrice,accuracy] = SteinSteinCall_MCGPU(q,r,T,dT,sigma,K,dirac,theta,kappa,ArraySpot,N)
optionPrices = arrayfun( @CallOption_Handler, ArraySpot, r, q, sigma, K, T, dT, dirac, theta, kappa);
meanOptionPrice = real(mean(optionPrices));
accuracy = std(optionPrices)/sqrt(N);
end

