function [MatrixStein, sumaerrores] = DosFor(Spot,q,r,T,step,sigma,K,dirac,theta,kappa,N,VolatilitiesD)
MatrixStein = zeros(1,35);
sumaerrores = 0;
tic;


for j=1:5 %Para los 5 Tenors
for i=1:7 %Para los 7 Delta
ArraySpot = Spot(1,1)*ones(N,1,'gpuArray'); %un d�a
[GPU_Call] = SteinSteinCall_MCGPU(q(1,j),r(1,j),T(1,j),step(1,j),sigma,K(1,i+(7*(j-1))),dirac,theta,kappa,ArraySpot,N);
[ImpVol] = NewtonRapsonGood(gather(GPU_Call),K(1,i+(7*(j-1))),T(1,j),1,r(1,j),q(1,j),Spot(1,1),0.00001,0.1);
MatrixStein(1,i+(7*(j-1))) = ImpVol*100; %/100
sumaerrores = abs(VolatilitiesD(1,i+(7*(j-1)))-MatrixStein(1,i+(7*(j-1)))) + sumaerrores;
end
end
sumaerrores = sumaerrores/(35);

toc;
end

