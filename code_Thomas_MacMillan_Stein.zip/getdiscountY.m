function [descontado] = getdiscountY(value,B);
    descontado = value/B;
end

