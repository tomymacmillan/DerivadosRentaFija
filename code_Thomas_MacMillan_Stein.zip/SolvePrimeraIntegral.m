function [S1] = SolvePrimeraIntegral(dirac,kappa,theta,sigma,mu,T,precio)
fun=real(integral(@(eta)PrimeraIntegral(dirac,kappa,theta,sigma,mu,T,precio,eta),-100,100));
S0 = ((2.*pi).^(-1)).*((exp(-mu.*T).*precio).^(-3/2)).*fun;
S1 = exp(-mu.*T).*S0;




%{
fun=real(integral(PrimeraIntegral(dirac,kappa,theta,sigma,mu,T,precio),-100,100));
S0 = (1./(2.*pi.*sqrt((precio.*exp(-mu.*T)).^3))).*fun;
S1 = exp(-mu.*T).*S0;
%}
end

