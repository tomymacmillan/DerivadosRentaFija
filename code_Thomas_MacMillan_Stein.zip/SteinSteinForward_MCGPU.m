function [meanOptionPrice,accuracy] = SteinSteinForward_MCGPU(q,r,T,dT,sigma,K,dirac,theta,kappa,ArraySpot,N)
optionPrices = arrayfun( @ForwardOption_Handler, ArraySpot, r, q, sigma, K, T, dT, dirac, theta, kappa);
meanOptionPrice = mean(optionPrices);
accuracy = std(optionPrices)/sqrt(N);
end

