function [Call] = SolveSegundaIntegral(dirac,kappa,theta,sigma,mu,T,K,r,Spot)
fun=real(integral(@(P)SegundaIntegral(dirac,kappa,theta,sigma,mu,T,K,P),K,1000,'ArrayValued',true));
Call_aux = exp(-r.*T)*fun;
Call = Call_aux*Spot;
end

